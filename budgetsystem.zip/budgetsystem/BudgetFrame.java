package budgetsystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Vector;

public class BudgetFrame extends JFrame {
    private String username;
    private JLabel incomeLabel, expenseLabel, balanceLabel, greetingLabel, lastUpdatedLabel, dateTimeLabel;
    private JTable historyTable;
    private Connection conn;
    private JPanel chartPanel, barChartPanel;
    private DefaultTableModel model;
    private JComboBox<String> filterBox;
    private JTextField searchField;

    public BudgetFrame(String username) {
        this.username = username;

        setTitle("💰 Budget Management Dashboard - " + username);
        setSize(1150, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(25, 25, 25));

        connectDB();
        setupUI();
        updateSummary();
        loadHistory();
    }

    private void connectDB() {
        try {
            conn = DBConnection.getConnection();
            System.out.println("✅ Database connected successfully.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + ex.getMessage());
        }
    }

    private void setupUI() {
        JLabel title = new JLabel("Budget Management Dashboard", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setBounds(300, 15, 500, 35);
        add(title);

        greetingLabel = new JLabel("Welcome, " + username + "!");
        greetingLabel.setFont(new Font("Segoe UI", Font.ITALIC, 15));
        greetingLabel.setForeground(new Color(200, 200, 200));
        greetingLabel.setBounds(25, 20, 250, 25);
        add(greetingLabel);

        dateTimeLabel = new JLabel();
        dateTimeLabel.setForeground(new Color(180, 180, 180));
        dateTimeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        dateTimeLabel.setBounds(25, 45, 350, 25);
        add(dateTimeLabel);
        updateDateTime();

        JButton logoutBtn = createButtonVisual("Logout", new Color(231, 76, 60), 980, 20, 100, 30);
        logoutBtn.addActionListener(e -> { dispose(); new LoginFrame().setVisible(true); });
        add(logoutBtn);

        int btnY = 90;
        JButton addIncomeBtn = createButtonVisual("➕ Add Income", new Color(46, 204, 113), 60, btnY, 160, 40);
        JButton addExpenseBtn = createButtonVisual("➖ Add Expense", new Color(52, 152, 219), 240, btnY, 160, 40);
        JButton refreshBtn = createButtonVisual("🔄 Refresh", new Color(155, 89, 182), 420, btnY, 130, 40);
        JButton editBtn = createButtonVisual("✏️ Edit", new Color(241, 196, 15), 570, btnY, 120, 40);
        JButton deleteBtn = createButtonVisual("🗑️ Delete", new Color(231, 76, 60), 710, btnY, 120, 40);

        addIncomeBtn.addActionListener(e -> openAddDialog("income"));
        addExpenseBtn.addActionListener(e -> openAddDialog("expense"));
        refreshBtn.addActionListener(e -> { updateSummary(); loadHistory(); repaint(); });
        editBtn.addActionListener(e -> editSelectedItem());
        deleteBtn.addActionListener(e -> deleteSelectedItem());

        add(addIncomeBtn);
        add(addExpenseBtn);
        add(refreshBtn);
        add(editBtn);
        add(deleteBtn);

        JPanel summaryPanel = new JPanel(null);
        summaryPanel.setBackground(new Color(35, 35, 35));
        summaryPanel.setBounds(50, 150, 1000, 80);
        add(summaryPanel);

        incomeLabel = createLabel("Total Income: ₹0", 70, 20);
        expenseLabel = createLabel("Total Expense: ₹0", 420, 20);
        balanceLabel = createLabel("Balance: ₹0", 770, 20);
        balanceLabel.setForeground(new Color(255, 215, 0));

        summaryPanel.add(incomeLabel);
        summaryPanel.add(expenseLabel);
        summaryPanel.add(balanceLabel);

        lastUpdatedLabel = new JLabel("Last updated: --");
        lastUpdatedLabel.setForeground(new Color(180, 180, 180));
        lastUpdatedLabel.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lastUpdatedLabel.setBounds(420, 55, 250, 20);
        summaryPanel.add(lastUpdatedLabel);

        JLabel historyLabel = new JLabel("Recent Transactions");
        historyLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        historyLabel.setForeground(Color.WHITE);
        historyLabel.setBounds(400, 250, 200, 25);
        add(historyLabel);

        filterBox = new JComboBox<>(new String[]{"All", "Income", "Expense"});
        filterBox.setBounds(400, 280, 130, 28);
        filterBox.addActionListener(e -> loadHistory());
        add(filterBox);

        searchField = new JTextField();
        searchField.setBounds(540, 280, 220, 28);
        searchField.setToolTipText("Search by name");
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { loadHistory(); }
        });
        add(searchField);

        // === Pie Chart ===
        chartPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawPieChart((Graphics2D) g);
            }
        };
        chartPanel.setBounds(60, 260, 300, 300);
        chartPanel.setBackground(new Color(35, 35, 35));
        chartPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.DARK_GRAY),
                "Income vs Expense (Pie Chart)",
                0, 0, new Font("Segoe UI", Font.BOLD, 14), Color.WHITE));
        add(chartPanel);

        // === Bar Chart ===
        barChartPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawBarChart((Graphics2D) g);
            }
        };
        barChartPanel.setBounds(60, 580, 300, 100);
        barChartPanel.setBackground(new Color(35, 35, 35));
        barChartPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.DARK_GRAY),
                "Income vs Expense (Bar Chart)",
                0, 0, new Font("Segoe UI", Font.BOLD, 14), Color.WHITE));
        add(barChartPanel);

        // === Table ===
        historyTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(historyTable);
        scrollPane.setBounds(400, 320, 650, 360);
        add(scrollPane);
    }

    private JButton createButtonVisual(String text, Color color, int x, int y, int w, int h) {
        JButton btn = new JButton(text);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBounds(x, y, w, h);
        btn.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(color.darker()); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(color); }
        });
        return btn;
    }

    private JLabel createLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        label.setBounds(x, y, 300, 30);
        return label;
    }

    private void updateDateTime() {
        Timer timer = new Timer(1000, e -> {
            String date = new SimpleDateFormat("EEEE, dd MMM yyyy | hh:mm:ss a").format(new java.util.Date());
            dateTimeLabel.setText(date);
        });
        timer.start();
    }

    // ================= Functional Methods =================

    private void openAddDialog(String type) {
        JTextField nameField = new JTextField();
        JTextField amountField = new JTextField();

        Object[] message = {
            "Name:", nameField,
            "Amount:", amountField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add " + type, JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                double amount = Double.parseDouble(amountField.getText());
                PreparedStatement pst = conn.prepareStatement(
                    "INSERT INTO budget_items(username, type, name, amount, date) VALUES(?,?,?,?,NOW())");
                pst.setString(1, username);
                pst.setString(2, type);
                pst.setString(3, nameField.getText());
                pst.setDouble(4, amount);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Added successfully!");
                updateSummary();
                loadHistory();
                repaint();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error adding item: " + ex.getMessage());
            }
        }
    }

    private void editSelectedItem() {
        int row = historyTable.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select an item to edit."); return; }

        int id = (int) historyTable.getValueAt(row, 0);
        String currentName = historyTable.getValueAt(row, 2).toString();
        String currentAmount = historyTable.getValueAt(row, 3).toString();

        JTextField nameField = new JTextField(currentName);
        JTextField amountField = new JTextField(currentAmount);

        Object[] message = {"Edit Name:", nameField, "Edit Amount:", amountField};
        int option = JOptionPane.showConfirmDialog(this, message, "Edit Item", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                PreparedStatement pst = conn.prepareStatement("UPDATE budget_items SET name=?, amount=? WHERE id=?");
                pst.setString(1, nameField.getText());
                pst.setDouble(2, Double.parseDouble(amountField.getText()));
                pst.setInt(3, id);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Updated successfully!");
                updateSummary();
                loadHistory();
                repaint();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error editing item: " + ex.getMessage());
            }
        }
    }

    private void deleteSelectedItem() {
        int row = historyTable.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select an item to delete."); return; }

        int id = (int) historyTable.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this item?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                PreparedStatement pst = conn.prepareStatement("DELETE FROM budget_items WHERE id=?");
                pst.setInt(1, id);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Deleted successfully!");
                updateSummary();
                loadHistory();
                repaint();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error deleting item: " + ex.getMessage());
            }
        }
    }

    private void loadHistory() {
        try {
            String filter = filterBox.getSelectedItem().toString();
            String search = searchField.getText().trim();
            String query = "SELECT id, type, name, amount, DATE_FORMAT(date, '%d-%m-%Y %h:%i %p') AS formatted_date FROM budget_items WHERE username=?";
            if (!filter.equals("All")) query += " AND type='" + filter.toLowerCase() + "'";
            if (!search.isEmpty()) query += " AND name LIKE ?";
            query += " ORDER BY date DESC";

            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, username);
            if (!search.isEmpty()) pst.setString(2, "%" + search + "%");

            ResultSet rs = pst.executeQuery();

            model = new DefaultTableModel(new String[]{"ID", "Type", "Name", "Amount", "Date"}, 0);
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("id"));
                row.add(rs.getString("type"));
                row.add(rs.getString("name"));
                row.add(rs.getDouble("amount"));
                row.add(rs.getString("formatted_date"));
                model.addRow(row);
            }
            historyTable.setModel(model);
            historyTable.getColumnModel().getColumn(0).setMinWidth(0);
            historyTable.getColumnModel().getColumn(0).setMaxWidth(0);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading history: " + ex.getMessage());
        }
    }

    private void updateSummary() {
        try {
            double income = getTotal("income");
            double expense = getTotal("expense");
            double balance = income - expense;

            incomeLabel.setText("Total Income: ₹" + income);
            expenseLabel.setText("Total Expense: ₹" + expense);
            balanceLabel.setText("Balance: ₹" + balance);
            lastUpdatedLabel.setText("Last updated: " + new SimpleDateFormat("hh:mm:ss a").format(new java.util.Date()));
            repaint();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    private void drawPieChart(Graphics2D g2) {
        double income = getTotal("income");
        double expense = getTotal("expense");
        double total = income + expense;
        if (total == 0) {
            g2.setColor(Color.GRAY);
            g2.drawString("No data to show", 100, 150);
            return;
        }

        int incomeAngle = (int) Math.round((income / total) * 360);

        g2.setColor(new Color(46, 204, 113));
        g2.fillArc(50, 60, 200, 200, 0, incomeAngle);

        g2.setColor(new Color(231, 76, 60));
        g2.fillArc(50, 60, 200, 200, incomeAngle, 360 - incomeAngle);

        g2.setColor(Color.WHITE);
        g2.drawString("Income", 90, 280);
        g2.drawString("Expense", 180, 280);
    }

    private void drawBarChart(Graphics2D g2) {
        double income = getTotal("income");
        double expense = getTotal("expense");

        int maxBarHeight = 60;
        int incomeHeight = (int) ((income / Math.max(income, expense)) * maxBarHeight);
        int expenseHeight = (int) ((expense / Math.max(income, expense)) * maxBarHeight);

        g2.setColor(new Color(46, 204, 113));
        g2.fillRect(80, 80 - incomeHeight, 80, incomeHeight);
        g2.setColor(new Color(231, 76, 60));
        g2.fillRect(200, 80 - expenseHeight, 80, expenseHeight);

        g2.setColor(Color.WHITE);
        g2.drawString("Income", 90, 95);
        g2.drawString("Expense", 205, 95);
    }

    private double getTotal(String type) {
        try {
            PreparedStatement pst = conn.prepareStatement("SELECT SUM(amount) FROM budget_items WHERE username=? AND type=?");
            pst.setString(1, username);
            pst.setString(2, type);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) return rs.getDouble(1);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return 0;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BudgetFrame("pree").setVisible(true));
    }
}
